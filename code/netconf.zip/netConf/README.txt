Start Matlab and run:
run_toy();
 for a demo on a toy graph

Or
Make sure matlab is installed and is added to path. Then do make.