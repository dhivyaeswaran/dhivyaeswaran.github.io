/* 
 * File:   main.cpp
 * Author: deswaran
 *
 * Created on June 21, 2016, 8:31 PM
 */

#include <iostream>
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include "ZooBP.hpp"
#include "TestCase.hpp"

using namespace std;

int main() {
   TestCase t; 
   ZooBP z(&t.A_pos, &t.A_neg, &t.E1, &t.E2);
    cout << "Elapsed time (in milli seconds): " << z.run() << "\n";
    cout << "ZooBeliefs of users:\n" << *z.B1 << "\n\n";
    cout << "ZooBeliefs of products:\n" << *z.B2 << "\n";
}
