#include "TestCase.hpp"

double TestCase::delta = 0.01;

/*  Ground truth:
 *  Users: 0, 2 -> 0 & 1 -> 1
 *  Products: 0, 3 -> 0 & 1, 2 -> 1 */

TestCase::TestCase() {
    int N1 = 3, N2 = 4;
    A_pos.resize(N1, N2);
    A_pos.insert(0, 0) = 1;
    A_pos.insert(0, 3) = 1;
    A_pos.insert(1, 1) = 1;
    A_pos.insert(1, 2) = 1;
    A_neg.resize(N1, N2);
    A_neg.insert(0, 1) = 1;
    A_neg.insert(2, 2) = 1;
    E1.resize(N1, 2);
    E1(0, 0) = delta; 
    E1(0, 1) = -delta;
    E2.resize(N2, 2);
}