#include "utils.hpp"
#include <Eigen/Core>

VectorXd * vectorize(MatrixXd *m) {
    MatrixXd m1 = m->transpose();
    VectorXd *v = new VectorXd();
    *v = Map<VectorXd>(m1.data(), m1.cols()*m1.rows());
    return v;
}

void blockCopyTripletList(vector< Triplet<double> > &triplet_list, int row_start, int col_start, 
        SparseMatrix<double> *m, bool transpose) {
    if(transpose == false) {
        for (int k=0; k<m->outerSize(); ++k) {
            for (SparseMatrix<double>::InnerIterator it(*m, k); it; ++it) {
                triplet_list.push_back( Triplet<double>(row_start+it.row(), col_start+it.col(), it.value()) );
            }
        }
    } else {
        for (int k=0; k<m->outerSize(); ++k) {
            for (SparseMatrix<double>::InnerIterator it(*m, k); it; ++it) {
                triplet_list.push_back( Triplet<double>(row_start+it.col(), col_start+it.row(), it.value()) );
            }
        }
    }
}

SparseMatrix<double> sparseIdentityMatrix(int size) {
    vector< Triplet<double> > triplet_list;
    triplet_list.reserve(size);
    for(int i=0; i<size; i++) {
        triplet_list.push_back( Triplet<double>(i, i, 1) );
    }
    SparseMatrix<double> speye(size, size);
    speye.setFromTriplets(triplet_list.begin(), triplet_list.end());
    return speye;
}

MatrixXd * devectorize(MatrixXd *v, int n_cols) {
    v->resize(n_cols, v->rows()/n_cols);
    MatrixXd *m = new MatrixXd();
    *m = v->transpose();
    return m;
}

SparseMatrix<double> * kroneckerProduct(SparseMatrix<double> * m1, MatrixXd *m2) {
    vector< Triplet<double> > triplet_list;
    int n_rows = m2->rows(), n_cols = m2->cols();
    triplet_list.reserve(m1->nonZeros()*n_rows*n_cols);
    for (int k=0; k<m1->outerSize(); ++k) {
        for (SparseMatrix<double>::InnerIterator it(*m1, k); it; ++it) {
            for(int i=0; i<n_rows; ++i) {
                for(int j=0; j<n_cols; ++j) {
                    triplet_list.push_back( Triplet<double>(it.row()*n_rows+i, it.col()*n_cols+j, it.value()*(*m2)(i,j)) );
                }
            }
        }
    }
    SparseMatrix<double> *product = new SparseMatrix<double>(m1->rows()*n_rows, m1->cols()*n_cols);
    product->setFromTriplets(triplet_list.begin(), triplet_list.end());
    return product;
}