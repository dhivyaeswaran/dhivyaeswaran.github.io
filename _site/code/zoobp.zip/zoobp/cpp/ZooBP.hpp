/*
 * File:   ZooBP.hpp
 * Author: deswaran
 *
 * Created on June 24, 2016, 10:24 PM
 */

#include <iostream>
#include <vector>

#include <Eigen/Dense>
#include <Eigen/Sparse>

#include "utils.hpp"

using Eigen::MatrixXd;
using Eigen::Matrix2d;
using Eigen::SparseMatrix;
using Eigen::VectorXd;
using namespace std;

#ifndef ZOOBP_HPP
#define ZOOBP_HPP

class ZooBP {

private:
    /* maximum number of iterations if convergence is hard to reach */
    int max_iter;

    /* number of users */
    int N1;

    /* number of products */
    int N2;

    /* epsilon for convergence */
    double eps;

    /* sparse N1xN2 adjacency matrix of positive and negative ratings */
    SparseMatrix<double> *A_pos;
    SparseMatrix<double> *A_neg;

    /* dense 2x2 edge compatibility matrix for positive edge
     * rows - user types - honest, fraud (respectively)
     * columns - product types - good, bad (respectively) */
    MatrixXd *H;

    /* N1x2 and N2x2 prior matrices for users (E1) and products (E2) */
    MatrixXd *E1;
    MatrixXd *E2;

    /* N1*2+N2*2-dimensional persona matrix */
    SparseMatrix<double> M;

    /* determines if the algorithm has converged */
    bool hasConverged(VectorXd *prev_B, VectorXd *cur_B, int cur_iter);

    /* helper functions for pre and post processing; refer to paper for explanations of P, Q and M matrices */
    void constructM();
    VectorXd *vectorizeAndStackPriors();
    SparseMatrix<double> *constructP();
    SparseMatrix<double> *constructDiagonalDegreeMatrix(int mode); /* users (mode=2); products (mode=1) */
    SparseMatrix<double> *constructQ();
    void devectorizeAndUnstackBeliefs(VectorXd *cur_B);

public:
    /* N1x2 and N2x2 final belief matrices for users (B1) and products (B2) */
    MatrixXd *B1;
    MatrixXd *B2;

    /* constructor to initialize adjacency and prior matrices */
    ZooBP(SparseMatrix<double> *A_pos, SparseMatrix<double> *A_neg, MatrixXd *E1, MatrixXd *E2);

    /* runs algorithm and returns time taken, in milliseconds */
     long long run();

};

#endif /* ZOOBP_HPP */
