/* 
 * File:   utils.hpp
 * Author: deswaran
 *
 * Created on June 24, 2016, 9:34 PM
 */

#include <iostream>
#include <vector>

#include <Eigen/Sparse>
#include <Eigen/Dense>

using Eigen::Triplet;
using Eigen::MatrixXd;
using Eigen::SparseMatrix;
using Eigen::SparseVector;
using Eigen::VectorXd;
using Eigen::Map;
using namespace std;

#ifndef UTILS_HPP
#define UTILS_HPP

/* stacks rows of matrix one below the other */
VectorXd *vectorize(MatrixXd *m);

/* appends triplet_list with list of nonzero entries in  m, offset by (row_start, col_start) */
void blockCopyTripletList(std::vector< Triplet<double> > &triplet_list, int row_start, int col_start, 
        SparseMatrix<double> *m, bool transpose);

/* returns sparse identity matrix */
SparseMatrix<double> sparseIdentityMatrix(int size);

/* converts vector into a matrix n_cols columns */
MatrixXd *devectorize(MatrixXd *v, int n_cols);

SparseMatrix<double> * kroneckerProduct(SparseMatrix<double> * m1, MatrixXd *m2);
#endif /* UTILS_HPP */

