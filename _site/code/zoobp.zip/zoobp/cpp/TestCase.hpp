/* 
 * File:   TestCase.hpp
 * Author: deswaran
 *
 * Created on June 24, 2016, 10:43 PM
 */

#include <iostream>
#include <fstream>
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <string>

using Eigen::SparseMatrix;
using Eigen::MatrixXd;
using Eigen::Triplet;
using namespace std;

#ifndef TESTCASE_HPP
#define TESTCASE_HPP

/* A class for test case  to indicate the parameters that need to be supplied by the user. */
class TestCase {

public:
    
    /*N1*N2 positive adjacency matrix*/
    SparseMatrix<double> A_pos;
    
    /*N1*N2 negative adjacency matrix*/
    SparseMatrix<double> A_neg;
    
    /*N1*2 residual user priors*/
    MatrixXd E1;
    
    /*N2*2 residual product priors*/
    MatrixXd E2;
    
    /*parameter controlling the prior strength for seeded nodes*/
    static double delta;
    
    /*constructor for default test case with 3 users and 4 products*/
    TestCase();
};

#endif /* TESTCASE_HPP */