/* 
 * File:   ZooBP.cpp
 * Author: deswaran
 * 
 * Created on June 24, 2016, 10:24 PM
 */

#include "ZooBP.hpp"

ZooBP::ZooBP(SparseMatrix<double> *A_pos, SparseMatrix<double> *A_neg, MatrixXd *E1, MatrixXd *E2) {
    max_iter = 10;
    this->A_pos = A_pos;
    this->A_neg = A_neg;
    this->E1 = E1;
    this->E2 = E2;
    H = new MatrixXd(2, 2);
    *H << 0.5, -0.5, -0.5, 0.5;
    N1 = A_pos->rows();
    N2 = A_pos->cols();
    eps = 1e-4;
    constructM();
}

bool ZooBP::hasConverged(VectorXd *prev_B, VectorXd *cur_B, int cur_iter) {
    if(cur_iter == max_iter) {
        return true;
    }
    if(cur_iter == 0) {
        return false;
    }
    VectorXd B_diff = *cur_B - *prev_B;
    return ( B_diff.norm() < eps*eps*1e-8);
}

void ZooBP::constructM() {
//    cout << "P... \n";
    SparseMatrix<double> *P = constructP();
//    cout << "Q... \n";
    SparseMatrix<double> *Q = constructQ();
//    cout << "M... \n";
    M = *P - *Q + sparseIdentityMatrix(N1*2+N2*2);
}

long long ZooBP::run() {
    VectorXd *E = vectorizeAndStackPriors();
    VectorXd E_copy = *E;
    VectorXd *cur_B = &E_copy; /* a convenient initialization */
    VectorXd *prev_B;
    /* algorithm, timed */
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    int cur_iter = 0;
    while(hasConverged(prev_B, cur_B, cur_iter) == false) {
        prev_B = cur_B;
        cur_B = new VectorXd();
        *cur_B = *E + M * (*prev_B); 
        cur_iter++;
    }
    std::chrono::steady_clock::time_point end= std::chrono::steady_clock::now();
    devectorizeAndUnstackBeliefs(cur_B);
    return std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
}

VectorXd * ZooBP::vectorizeAndStackPriors() {
    VectorXd *vecE = new VectorXd(N1*2+N2*2);
    VectorXd *vecE1 = vectorize(E1);
    VectorXd *vecE2 = vectorize(E2);
    *vecE << *vecE1,  *vecE2;
    return vecE;
}

SparseMatrix<double> * ZooBP::constructP() {
    SparseMatrix<double> A_diff = *A_pos - *A_neg;
    MatrixXd H1 = 0.5*eps*(*H);
    SparseMatrix<double> *R = kroneckerProduct(&A_diff, &H1);
    vector< Triplet<double> > triplet_list;
    triplet_list.reserve(2*R->nonZeros());
    blockCopyTripletList(triplet_list, 0, N1*2, R, false);
    blockCopyTripletList(triplet_list, N1*2, 0, R, true);
    SparseMatrix<double> *P = new SparseMatrix<double>(N1*2+N2*2, N1*2+N2*2);
    P->setFromTriplets(triplet_list.begin(), triplet_list.end());
    return P;
}

SparseMatrix<double> * ZooBP::constructQ() {
    SparseMatrix<double> *D1 = constructDiagonalDegreeMatrix(2);
    SparseMatrix<double> *D2 = constructDiagonalDegreeMatrix(1);
    MatrixXd H2 = 0.25*eps*eps*(*H);
    SparseMatrix<double> Q1 = sparseIdentityMatrix(N1*2) + *kroneckerProduct(D1, &H2);
    SparseMatrix<double> Q2 = sparseIdentityMatrix(N2*2) + *kroneckerProduct(D2, &H2);
    vector< Triplet<double> > triplet_list;
    triplet_list.reserve(Q1.nonZeros() + Q2.nonZeros());
    blockCopyTripletList(triplet_list, 0, 0, &Q1, false);
    blockCopyTripletList(triplet_list, N1*2, N1*2, &Q2, false);
    SparseMatrix<double> *Q = new SparseMatrix<double>(N1*2+N2*2, N1*2+N2*2);
    Q->setFromTriplets(triplet_list.begin(), triplet_list.end());
    return Q;
}

/* TODO: perform A_sum only once */
SparseMatrix<double> * ZooBP::constructDiagonalDegreeMatrix(int dim_to_squash) {
    SparseMatrix<double> A_sum = *A_pos + *A_neg;
    SparseMatrix<double> *degree_matrix;
     vector< Triplet<double> > triplet_list;
    triplet_list.reserve(A_sum.nonZeros());
    if(dim_to_squash == 2) {
        degree_matrix = new SparseMatrix<double>(N1, N1);
        for (int k=0; k<A_sum.outerSize(); ++k) {
            for (SparseMatrix<double>::InnerIterator it(A_sum, k); it; ++it) {
                triplet_list.push_back( Triplet<double>(it.row(), it.row(), it.value()) );
            }
        }
    } else {
        degree_matrix = new SparseMatrix<double>(N2, N2);
        for (int k=0; k<A_sum.outerSize(); ++k) {
            for (SparseMatrix<double>::InnerIterator it(A_sum, k); it; ++it) {
                triplet_list.push_back( Triplet<double>(it.col(), it.col(), it.value()) );
            }
        }
    }
    degree_matrix->setFromTriplets(triplet_list.begin(), triplet_list.end());
    return degree_matrix;
}

void ZooBP::devectorizeAndUnstackBeliefs(VectorXd *B) {
    MatrixXd block1 = B->block(0, 0, N1*2, 1);
    B1 = devectorize((MatrixXd *)&block1, 2);
    MatrixXd block2 = B->block(N1*2, 0, N2*2, 1);
    B2 = devectorize((MatrixXd *)&block2, 2);
}