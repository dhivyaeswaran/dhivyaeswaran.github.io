% Author : Dhivya Eswaran 
% Email: deswaran@cs.cmu.edu
% Copyright July 1, 2016
% Available for academic use only, not for commercial use

This package gives the MATLAB code for the ZooBP applied to the review fraud setting.
To run this package,

Start Matlab and carry out the following steps:
load toy/adjList.mat
[userBelief, prodBelief, stats] = reviewZooBP(L);
 for a demo on a toy graph

OR

run the make file.
 