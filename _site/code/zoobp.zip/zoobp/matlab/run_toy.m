function run_toy()
    load toy/adjList.mat;
    [userBelief, prodBelief, stats] = reviewZooBP(L);
    csvwrite('toy/userBeliefs.csv',userBelief); 
    csvwrite('toy/productBeliefs.csv',prodBelief);
end